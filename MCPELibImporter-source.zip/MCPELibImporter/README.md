# MCPE Lib Importer — Android App

Import native `.so` libs and Minecraft world packs, package them as a ZIP — all from your phone.

## Features
- Pick `.so` native lib files → bundled by architecture
- Pick resource/behavior packs (`.mcpack`, `.mcaddon`, `manifest.json`, etc.)
- Pick `.mcworld` world saves
- Auto-generates `manifest.json` with proper UUIDs
- Generates `install.sh` for Termux/root install
- Saves ZIP directly to your Downloads folder

## Build via GitHub Actions

1. **Upload this folder to a new GitHub repo**
2. Go to **Actions** tab → click **Build APK** → **Run workflow**
3. Download the APK artifact when done
4. Install on your phone (enable Unknown Sources)

## Project Structure
```
app/src/main/
  assets/importer.html   ← The full UI (edit this to mod the app)
  java/.../MainActivity.java  ← WebView + file picker + ZIP save bridge
  AndroidManifest.xml
```

## Modding the App
To change the UI or add features:
1. Edit `app/src/main/assets/importer.html`
2. Push to GitHub → Actions auto-builds a new APK

## Package Info
- Package: `com.crazyclient.libimporter`
- Min Android: 7.0 (API 24)
- Target: Android 14 (API 34)
